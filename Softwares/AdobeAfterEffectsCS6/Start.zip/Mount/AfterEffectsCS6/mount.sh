#!/bin/bash
/home/colab/Colab-Apps/Dependencies/logo
echo "$(tput setaf 6)"
echo "$========================================================================================================="
echo "$(tput setaf 1) Manual Interaction Required!!!"
echo "$(tput setaf 6)1. Click Drives"
echo "2. Click The Add Button"
echo "3. Click OK Button"
echo "4. Click Apply Button"
echo "5. Last, Click The Okay Button At The Bottom"
echo "$========================================================================================================="
echo ""
echo "Do You Want To Proceed Now?"
PS3='Please enter your choice: '
options=("Yes" "No")
select opt in "${options[@]}"
do
    case $opt in
        "Yes")
            echo "$========================================================================================================="
echo "Starting Wine Configuration"      
echo "========================================================================================================="
WINEPREFIX="$HOME/.sakurayuich-colabapps/aecs6" WINEARCH=win64 winecfg
clear
break
            ;;
        "No")
        clear
            break
            ;;
        *) echo "Invalid Option ╯︿╰ $REPLY";;
    esac
done
